function aboutme(){
    return(
        <div>
            <p><b>학력 : 조선대학교 컴퓨터공학과 1학년</b></p>
            <p>고등학생때까지 취미로 조금씩 코딩을 하다가 전문적으로 배워보고싶어서 진학하게 되었습니다.</p>
            <p><b>Github : <button><a href="https://github.com/SUN-AAA">Visit</a></button></b></p>
            <p><b>Baekjoon : Silver 5</b></p>
            <a href="https://solved.ac/profile/sunna0626">
            <img src="https://mazassumnida.wtf/api/generate_badge?boj=sunna0626" alt="Solved.ac Profile" />
            </a>
            <p><b>Mail : sun20060626@gmail.com</b></p>
            <p><b>Instagram : sunor06</b></p>
            <h3><b>Language</b></h3>
            <img src="https://img.shields.io/badge/c-A8B9CC?style=for-the-badge&logo=c&logoColor=white"></img>
            <img src="https://img.shields.io/badge/javascript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=white"></img>
            <img src="https://img.shields.io/badge/python-3776AB?style=for-the-badge&logo=python&logoColor=white"></img>
            <img src="https://img.shields.io/badge/html5-E34F26?style=for-the-badge&logo=html5&logoColor=white"></img>
            <img src="https://img.shields.io/badge/css-663399?style=for-the-badge&logo=css&logoColor=white"></img>
            <h3><b>Tools</b></h3>
            <img src="https://img.shields.io/badge/notion-000000?style=for-the-badge&logo=notion&logoColor=white"></img>
            <img src="https://img.shields.io/badge/discord-5865F2?style=for-the-badge&logo=discord&logoColor=white"></img>
            <img src="https://img.shields.io/badge/github-181717?style=for-the-badge&logo=github&logoColor=white"></img>
            <h3><b>Learning</b></h3>
            <img src="https://img.shields.io/badge/react-61DAFB?style=for-the-badge&logo=react&logoColor=white"></img>
            <img src="https://img.shields.io/badge/node.js-5FA04E?style=for-the-badge&logo=node.js&logoColor=white"></img>
            <br></br>
            <br></br> 
        </div>
    )
}

export default aboutme;