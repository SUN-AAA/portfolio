import "../styles/flexbox.css";

function project(){
    return(
        <div class="comtainer">
            <div class="item">
                <p><a href="https://www.sunaaa.kr/" class="item"><b>포트폴리오 프로젝트</b></a></p>
            </div>
        </div>
    )
}

export default project;