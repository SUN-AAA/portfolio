import "../styles/flexbox.css";

function nav(){
    return(
        <div class="container">
            <div><a href="#profile" class="item"><b>PROFILE</b></a></div>
            <div><a href="#aboutme" class="item"><b>ABOUT ME</b></a></div>
            <div><a href="#project" class="item"><b>PROJECT</b></a></div>
            <br></br>
            <br></br>
            <br></br>
        </div>
    )
}

export default nav;