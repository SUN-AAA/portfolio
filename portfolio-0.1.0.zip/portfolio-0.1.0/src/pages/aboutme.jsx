import Aboutme from "../components/aboutme";

function aboutme(){
    return(
        <div id="aboutme">
            <hr></hr>
            <h2>About Me</h2>
            <Aboutme/>
        </div>
    )
}

export default aboutme;