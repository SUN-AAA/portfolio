import Project from "../components/project";
function project(){
    return(
        <div id="project">
            <hr></hr>
            <h2>PROJECT</h2>
            <Project/>
        </div>
    )
}

export default project;