import Profile from"../components/profile";

function profile(){
    return(
        <div id="profile">
            <Profile/>
        </div>
    )
}

export default profile;