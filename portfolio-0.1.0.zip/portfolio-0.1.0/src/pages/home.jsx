import Header from "../components/header";
import Nav from "../components/nav";

function home() {
    return(
        <div id="home">
            <Header/>
            <Nav/>
        </div>
    )
}

export default home;